package com.kh.basic;

public class HelloWorld {
	//한줄주석
	/*
	 	여러줄 주석
	*/
	
	//main메서드
	//자바코드의 실행을 담당
	public static void main(String[] args) {
		System.out.println("Hello, World!");
	}
}
