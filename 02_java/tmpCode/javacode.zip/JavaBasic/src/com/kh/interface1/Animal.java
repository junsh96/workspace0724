package com.kh.interface1;

public interface Animal {
	/*public abstract*/ void speak(); //소리내기
	public abstract void move(); //움직이기
}
