package com.kh.example.oop1;

public class Run {

	public static void main(String[] args) {
		Product p1 = new Product();
		p1.setpName("아이폰16");
		p1.setPrice(1600000);
		p1.setBrand("애플");
		p1.information();

	}

}
