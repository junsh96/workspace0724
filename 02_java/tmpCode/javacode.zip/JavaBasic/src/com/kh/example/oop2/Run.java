package com.kh.example.oop2;

public class Run {

	public static void main(String[] args) {
		Student st = new Student();
		System.out.println(st.information());;
	}

}
