package com.kh.example.api;

public class Run {

	public static void main(String[] args) {
		new TokenMenu().mainMenu();
	}

}
