package com.kh.example.oop4;

public class Run {
	public static void main(String[] args) {
//		ShapeMenu sm = new ShapeMenu();
//		sm.inputMenu();
		new ShapeMenu().inputMenu();
	}
}
