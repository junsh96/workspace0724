package com.kh.example.abstractNInterface;

public interface TouchDisplay {
	String touch(); 
}
