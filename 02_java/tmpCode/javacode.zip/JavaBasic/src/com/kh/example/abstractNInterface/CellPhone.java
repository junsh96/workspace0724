package com.kh.example.abstractNInterface;

public interface CellPhone {
	String charge();
}
