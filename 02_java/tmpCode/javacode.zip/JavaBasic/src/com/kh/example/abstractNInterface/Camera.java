package com.kh.example.abstractNInterface;

public interface Camera {
	String picture();
}
