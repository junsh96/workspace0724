package com.kh.example.exception1;

public class Run {

	public static void main(String[] args) throws CharCheckException {
		new CharacterMenu().menu();
		System.out.println("정상종료");
	}

}
