package com.kh.example.abstractNInterface;

public interface NotePen {
	boolean PEN_BUTTON = true;
	
	boolean bluetoothPen();
}
