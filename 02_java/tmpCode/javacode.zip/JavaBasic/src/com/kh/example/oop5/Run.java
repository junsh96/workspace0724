package com.kh.example.oop5;

public class Run {

	public static void main(String[] args) {
		new SnackMenu().menu();

	}

}
