package com.kh.example.oop6;

public class Run {

	public static void main(String[] args) {
		new StudentMenu();

	}

}
