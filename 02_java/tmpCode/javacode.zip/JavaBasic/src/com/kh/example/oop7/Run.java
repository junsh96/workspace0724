package com.kh.example.oop7;

public class Run {

	public static void main(String[] args) {
		new ProductMenu().mainMenu();
	}

}
