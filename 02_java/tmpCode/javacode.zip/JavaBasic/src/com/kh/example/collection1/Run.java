package com.kh.example.collection1;

public class Run {

	public static void main(String[] args) {
		new MusicView().mainMenu();
	}

}
