package com.kh.polymorphism;

public class Cake {
	public void sweet() {
		System.out.println("cake sweet");
	}
	
	public void yummy() {
		System.out.println("cake yummy");
	}
}
